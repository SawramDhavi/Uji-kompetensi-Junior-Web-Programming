<?php 
require "function.php";

$kdmk = $_GET["kdmk"];

if ( hapus($kdmk) > 0 ) {
    echo"<script>
            alert('Data berhasil dihapus');
            document.location.href = 'mtkl.php';    
        </script>";
} else {
    echo"<script>
            alert('Data gagal dihapus');                
            document.location.href = 'mtkl.php'; 
        </script>";
}
?>