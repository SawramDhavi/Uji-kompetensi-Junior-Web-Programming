<?php 
session_start();

if (!isset($_SESSION["login"]) ) {
  header("Location: login.php");
  exit;
}

require "function.php";

$npm = $_GET["npm"];

if ( hapusmhs($npm) > 0 ) {
    echo"<script>
            alert('Data berhasil dihapus');
            document.location.href = 'index.php';    
        </script>";
} else {
    echo mysqli_error($conn);
}
?>