-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Waktu pembuatan: 30 Jun 2021 pada 17.04
-- Versi server: 10.4.14-MariaDB
-- Versi PHP: 7.4.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `jewepe`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `admin`
--

CREATE TABLE `admin` (
  `id` int(11) NOT NULL,
  `username` varchar(35) NOT NULL,
  `password` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data untuk tabel `admin`
--

INSERT INTO `admin` (`id`, `username`, `password`) VALUES
(2, 'dhavisens', '$2y$10$PYLCiV.HDIoyGvV6n.zDAem6896SJJeXO5ok9gzlqPVIOTIah1M8K');

-- --------------------------------------------------------

--
-- Struktur dari tabel `mahasiswa`
--

CREATE TABLE `mahasiswa` (
  `id` int(11) NOT NULL,
  `nama` varchar(35) NOT NULL,
  `npm` char(8) NOT NULL,
  `kelas` varchar(7) NOT NULL,
  `jurusan` varchar(35) NOT NULL,
  `matkul` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data untuk tabel `mahasiswa`
--

INSERT INTO `mahasiswa` (`id`, `nama`, `npm`, `kelas`, `jurusan`, `matkul`) VALUES
(27, 'dinda ayu oka mulyana', '36118563', '3db01', 'teknik informatika', 'Algoritma Pemrograman,sistem informasi,pengantar sistem komputer,Olah Data Statistika,Matematika Dasar,Terapan Perbankan'),
(2, 'Rio Devanka', '36171812', '3db01', 'manajemen', 'Algoritma Pemrograman,sistem informasi,pengantar sistem komputer'),
(26, 'ucok', '36251643', '3db02', 'teknik informatika', 'sistem informasi,pengantar sistem komputer,Matematika Dasar'),
(25, 'Dodi Pratama', '36273564', '3db02', 'Manajemen Informatika', 'pengantar sistem komputer,Matematika Dasar,Terapan Perbankan'),
(0, 'hehehe', '82726176', '3db02', 'mesin', 'Olah Data Statistika,Matematika Dasar');

-- --------------------------------------------------------

--
-- Struktur dari tabel `mata_kuliah`
--

CREATE TABLE `mata_kuliah` (
  `matkul` varchar(35) NOT NULL,
  `kdmk` char(4) NOT NULL,
  `sks` varchar(35) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data untuk tabel `mata_kuliah`
--

INSERT INTO `mata_kuliah` (`matkul`, `kdmk`, `sks`) VALUES
('sistem informasi', 'kd00', '2 sks'),
('sistem informasi', 'kd01', '3 sks'),
('bahasa inggris', 'kd02', '2 sks'),
('pengantar sistem komputer', 'kd03', '2 sks');

-- --------------------------------------------------------

--
-- Struktur dari tabel `mtkl`
--

CREATE TABLE `mtkl` (
  `id` int(11) NOT NULL,
  `kdmk` char(4) NOT NULL,
  `matkul` varchar(35) NOT NULL,
  `sks` varchar(8) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data untuk tabel `mtkl`
--

INSERT INTO `mtkl` (`id`, `kdmk`, `matkul`, `sks`) VALUES
(6, 'kd01', 'Algoritma Pemrograman', '5 sks'),
(7, 'kd02', 'sistem informasi', '2 sks'),
(8, 'kd03', 'pengantar sistem komputer', '2 sks'),
(9, 'kd04', 'Olah Data Statistika', '3 sks'),
(10, 'kd05', 'Matematika Dasar', '2 sks'),
(11, 'kd05', 'Terapan Perbankan', '2 sks');

-- --------------------------------------------------------

--
-- Struktur dari tabel `user`
--

CREATE TABLE `user` (
  `id` int(11) NOT NULL,
  `username` varchar(35) NOT NULL,
  `password` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data untuk tabel `user`
--

INSERT INTO `user` (`id`, `username`, `password`) VALUES
(1, 'titohandaru', '$2y$10$loinNbjKuZPuMkVyYoOKGuYM.UQUj8iWnvJRRxXJRRvPn5r12YWIu');

--
-- Indexes for dumped tables
--

--
-- Indeks untuk tabel `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `mahasiswa`
--
ALTER TABLE `mahasiswa`
  ADD PRIMARY KEY (`npm`) USING BTREE;

--
-- Indeks untuk tabel `mata_kuliah`
--
ALTER TABLE `mata_kuliah`
  ADD PRIMARY KEY (`kdmk`);

--
-- Indeks untuk tabel `mtkl`
--
ALTER TABLE `mtkl`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT untuk tabel yang dibuang
--

--
-- AUTO_INCREMENT untuk tabel `admin`
--
ALTER TABLE `admin`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT untuk tabel `mtkl`
--
ALTER TABLE `mtkl`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT untuk tabel `user`
--
ALTER TABLE `user`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
